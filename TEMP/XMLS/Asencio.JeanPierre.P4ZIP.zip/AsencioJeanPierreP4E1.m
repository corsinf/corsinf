%Materia: Matemáticas Discretas
%Grupo: GR2COM
%Nombre: Jean Pierre Asencio
%Fecha: 06/08/2021

A = [1 2 26 20 4];
x = input('Seleccione el número a buscar: ');
auxiliar = 0;
for c = 1:5 
    if A(1, c) == x 
        disp (['Número ubicado en la columna: ', num2str(c)])
        auxiliar = auxiliar + 1;
    end
end

if auxiliar == 0 
    disp ('Número no encontrado en el arreglo')
end

