%Materia: Matemáticas Discretas
%Grupo: GR2COM
%Nombre: Jean Pierre Asencio
%Fecha: 06/08/2021

A = [1 2 3 4 5];
x = input('Inserte el número para agregar: ');
y = input('Inserte la posición de la columna del número agregado: ');
if y >=5
    A(1,y) = x;
else
    for c = 5:-1:y
        A(1,c+1)= A(1,c);
    end
    A(1,y) = x;
end
disp(A)
disp('Arreglo ordenado')
sort(A)


